print 5
