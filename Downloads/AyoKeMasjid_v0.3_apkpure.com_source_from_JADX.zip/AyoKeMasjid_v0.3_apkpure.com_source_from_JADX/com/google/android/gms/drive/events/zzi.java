package com.google.android.gms.drive.events;

public interface zzi extends zzf {
    void zza(ProgressEvent progressEvent);
}
