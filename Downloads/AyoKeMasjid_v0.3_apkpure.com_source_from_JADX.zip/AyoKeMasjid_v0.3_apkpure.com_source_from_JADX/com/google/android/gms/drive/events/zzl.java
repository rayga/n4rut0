package com.google.android.gms.drive.events;

public interface zzl extends zzf {
    void zza(zzj com_google_android_gms_drive_events_zzj);

    void zzcs(int i);
}
