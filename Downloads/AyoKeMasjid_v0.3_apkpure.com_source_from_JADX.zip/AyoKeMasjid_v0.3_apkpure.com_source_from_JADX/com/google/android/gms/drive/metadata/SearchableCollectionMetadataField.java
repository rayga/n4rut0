package com.google.android.gms.drive.metadata;

import java.util.Collection;

public interface SearchableCollectionMetadataField<T> extends SearchableMetadataField<Collection<T>> {
}
