package com.google.android.gms.cast.internal;

public interface zzo {
    void zza(long j, int i, Object obj);

    void zzy(long j);
}
