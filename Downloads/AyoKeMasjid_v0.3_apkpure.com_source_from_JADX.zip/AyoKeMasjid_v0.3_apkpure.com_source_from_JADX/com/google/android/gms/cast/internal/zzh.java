package com.google.android.gms.cast.internal;

import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.Result;
import com.google.android.gms.common.api.Status;

public abstract class zzh extends zzb<Status> {
    public zzh(GoogleApiClient googleApiClient) {
        super(googleApiClient);
    }

    public /* synthetic */ Result zzb(Status status) {
        return zzd(status);
    }

    public Status zzd(Status status) {
        return status;
    }
}
