package com.google.android.gms.internal;

import android.net.Uri;

public interface zzoh {
    void zzb(zzob com_google_android_gms_internal_zzob);

    Uri zzhs();
}
