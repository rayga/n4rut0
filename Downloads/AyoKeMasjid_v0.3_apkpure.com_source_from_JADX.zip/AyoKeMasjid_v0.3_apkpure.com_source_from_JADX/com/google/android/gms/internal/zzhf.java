package com.google.android.gms.internal;

public interface zzhf {
    String zzat(String str);
}
