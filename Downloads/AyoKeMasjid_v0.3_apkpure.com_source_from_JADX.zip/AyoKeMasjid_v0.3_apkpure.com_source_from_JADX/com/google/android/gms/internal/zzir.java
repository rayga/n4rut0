package com.google.android.gms.internal;

import android.content.Context;
import com.google.android.gms.ads.internal.client.AdSizeParcel;
import com.google.android.gms.ads.internal.util.client.VersionInfoParcel;
import com.google.android.gms.ads.internal.zzd;

@zzgk
public class zzir {
    public zzip zza(Context context, AdSizeParcel adSizeParcel, boolean z, boolean z2, zzan com_google_android_gms_internal_zzan, VersionInfoParcel versionInfoParcel) {
        return zzis.zzb(context, adSizeParcel, z, z2, com_google_android_gms_internal_zzan, versionInfoParcel, null);
    }

    public zzip zza(Context context, AdSizeParcel adSizeParcel, boolean z, boolean z2, zzan com_google_android_gms_internal_zzan, VersionInfoParcel versionInfoParcel, zzd com_google_android_gms_ads_internal_zzd) {
        return zzis.zzb(context, adSizeParcel, z, z2, com_google_android_gms_internal_zzan, versionInfoParcel, com_google_android_gms_ads_internal_zzd);
    }
}
