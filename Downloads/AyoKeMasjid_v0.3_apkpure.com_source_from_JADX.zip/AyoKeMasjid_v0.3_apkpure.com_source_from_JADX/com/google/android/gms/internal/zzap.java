package com.google.android.gms.internal;

public interface zzap {
    String zza(byte[] bArr, boolean z);

    byte[] zza(String str, boolean z) throws IllegalArgumentException;
}
