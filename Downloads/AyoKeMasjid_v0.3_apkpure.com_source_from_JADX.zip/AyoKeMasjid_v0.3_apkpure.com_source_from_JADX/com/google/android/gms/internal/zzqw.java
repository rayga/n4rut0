package com.google.android.gms.internal;

import android.os.Build.VERSION;

public class zzqw {
    public zzqv zzBW() {
        return zzzz() < 8 ? new zzqt() : new zzqu();
    }

    int zzzz() {
        return VERSION.SDK_INT;
    }
}
