package com.google.android.gms.wearable.internal;

import com.google.android.gms.wearable.zzk;

public final class zzbp implements zzk {
}
