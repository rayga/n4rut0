package com.google.android.gms.wearable.internal;

final class zzl {
    final int zzaZP;
    final int zzaZQ;

    zzl(int i, int i2) {
        this.zzaZP = i;
        this.zzaZQ = i2;
    }
}
