package com.google.android.gms.wearable;

import com.google.android.gms.wearable.zza.zza;

public abstract class zzj extends WearableListenerService implements zza, zzc.zza {
    public void zza(zzb com_google_android_gms_wearable_zzb) {
    }

    public void zza(zzd com_google_android_gms_wearable_zzd) {
    }
}
