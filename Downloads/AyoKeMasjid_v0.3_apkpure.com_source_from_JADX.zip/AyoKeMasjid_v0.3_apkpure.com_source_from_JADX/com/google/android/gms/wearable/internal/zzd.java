package com.google.android.gms.wearable.internal;

import com.google.android.gms.wearable.zza;

public final class zzd implements zza {
}
