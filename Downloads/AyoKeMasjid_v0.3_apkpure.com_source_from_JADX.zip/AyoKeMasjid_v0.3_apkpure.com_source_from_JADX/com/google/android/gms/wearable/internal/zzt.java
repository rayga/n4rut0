package com.google.android.gms.wearable.internal;

interface zzt {
    void zzb(zzl com_google_android_gms_wearable_internal_zzl);
}
