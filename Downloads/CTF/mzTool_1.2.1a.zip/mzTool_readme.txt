*******************************************************************************
|                                                                             |
|                              mzTool  README                                 |
|                                                                             |
*******************************************************************************

                                                        Last Update : 2012.2.1
* This file is encoded with UTF-8

===============================================================================
|   Release Notes                                                             |
===============================================================================
MZTL_1.2.1a      - 2012.2.1 (Wed)
  -o- [#9] [mztl] SKT/KT band_pref value change
        -. UMTS 1,2,5,8 bands & GSM Quad-bands

MZTL_1.2.1       - 2012.1.27 (Fri)
  (R) MZTL_1.2.1
  (N) [#7] makefile.gcc creation for command-line build 

MZTL_1.20        - 2012.1.25 (Wed)
  (R) MZTL_1.20
  (N) NV item value calcuation for band preferences (Band Preference (NV value) Tab)

MZTL_1.10        - 2012.1.24 (Tue)
  (R) MZTL_1.10
  (N) [#4] GUI change with wxFormBuilder 

MZTL_1.00        - 2012.1.24 (Tue)
  (R) MZTL_1.00
  (+) Getting bit information for decimal and hex input of NV_BAND_PREF_I, 
      NV_BAND_PREF_16_31_I, NV_BAND_PREF_32_63_I, NV_RF_BC_CONFIG_I


===============================================================================
|   Bug Reports                                                               |
===============================================================================
Name : Hwang Minjae
E-mail : minnznt@gmail.com

-. 에러가 발생한 내역에 대해 자세히 알려주세요.
-. 에러가 발생한 파일도 같이 보내주세요.



/* END of README */
